### THIS FILE CONTAINS THE SCHEMA FOR TABLES IN THE DATA BASE

GUEST_TABLE_NAME = "Guest"
GUEST_TABLE_FIELDS = [
    ("id", "varchar(255)"),
    ("first_name", "varchar(255)")
]

